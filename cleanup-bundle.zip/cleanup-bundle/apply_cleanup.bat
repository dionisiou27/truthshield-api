@echo off
REM ============================================================
REM  TruthShield P0+P1 Cleanup — Anwendungs-Script (Windows)
REM  Ausfuehren im Root des truthshield-api Repos
REM ============================================================

echo.
echo === P0.1: requirements.txt ersetzen ===
copy /Y cleanup-bundle\requirements.txt requirements.txt
copy /Y cleanup-bundle\requirements-future.txt requirements-future.txt

echo.
echo === P0.2: __pycache__ aus Git entfernen ===
git rm -r --cached src\api\__pycache__ 2>nul
git rm -r --cached src\core\__pycache__ 2>nul
git rm -r --cached src\services\__pycache__ 2>nul

echo.
echo === P0.3: CLAUDE.md ersetzen ===
copy /Y cleanup-bundle\CLAUDE.md CLAUDE.md

echo.
echo === P0.4+P0.5: src/api/main.py ersetzen ===
copy /Y cleanup-bundle\src\api_main.py src\api\main.py

echo.
echo === P1.6: Root-Level Dateien verschieben ===
if not exist scripts mkdir scripts
if not exist tests\exploratory mkdir tests\exploratory
git mv simple_api_test.py tests\exploratory\simple_api_test.py 2>nul
git mv demo_script.py scripts\demo_script.py 2>nul
git mv streamlit_app.py scripts\streamlit_app.py 2>nul
git mv create_strategy.ps1 scripts\create_strategy.ps1 2>nul

echo.
echo === P1.7: ai_engine.py refactoring ===
copy /Y cleanup-bundle\src\core\ai_engine.py src\core\ai_engine.py
copy /Y cleanup-bundle\src\core\personas.py src\core\personas.py
copy /Y cleanup-bundle\src\core\text_detection.py src\core\text_detection.py

echo.
echo === P1.8: docs/ cleanup ===
git rm docs\test.html 2>nul
git mv "docs\Technical Architecture.html" docs\technical_architecture.html 2>nul

echo.
echo === STRATEGY aus Tracking entfernen ===
echo.>> .gitignore
echo # Operational strategy docs — sensitive, moved to private repo>> .gitignore
echo STRATEGY/>> .gitignore
git rm -r --cached STRATEGY 2>nul

echo.
echo === CLEANUP.md hinzufuegen ===
copy /Y cleanup-bundle\CLEANUP.md CLEANUP.md

echo.
echo ============================================================
echo  FERTIG. Jetzt:
echo    git add -A
echo    git commit -m "refactor: P0+P1 repository cleanup"
echo    git push
echo ============================================================
